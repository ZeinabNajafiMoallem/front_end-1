const discountData = [
  {
    coupon: "FX20",
    couponDate: "Oct10,2023",
    couponPercent: 20,
  },
  {
    coupon: "FX15",
    couponDate: "Jun5,2023",
    couponPercent: 15,
  },
  {
    coupon: "FX30",
    couponDate: "Jun10,2023",
    couponPercent: 30,
  },
  {
    coupon: "FX70",
    couponDate: "Oct12,2023",
    couponPercent: 70,
  },
];

export default discountData;
