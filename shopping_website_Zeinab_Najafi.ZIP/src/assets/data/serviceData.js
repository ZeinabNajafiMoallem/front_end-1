const serviceData = [
  {
    icon: "bi bi-truck",
    subtitle: "توضیحات",
    bg: "#e0ffff",
  },
  {
    icon: "bi bi-arrow-clockwise",
    subtitle: "توضیحات",
    bg: "#fffff0",
  },
  {
    icon: "bi bi-credit-card-2-back",
    subtitle: "توضیحات",
    bg: "#ffe4e1",
  },
  {
    icon: "bi bi-currency-exchange",
    subtitle: "توضیحات",
    bg: "#f5f5f5",
  },
];

export default serviceData;
