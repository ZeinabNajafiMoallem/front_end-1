import React from 'react'

function Rating({value,text,color}) {
  return (
    <div className='rating'>
      <span>
        <i style={{color}} className={
            value >= 1 ? 'bi bi-star-fill'//solid star
            :value >=0.5 ? 'bi bi-star-half' : 'bi bi-star'
        }></i>
      </span>
      <span>
        <i style={{color}} className={
            value >= 2 ? 'bi bi-star-fill'//solid star
            :value >=1.5 ? 'bi bi-star-half' : 'bi bi-star'
        }></i>
      </span>
      <span>
        <i style={{color}} className={
            value >= 3 ? 'bi bi-star-fill'//solid star
            :value >=2.5 ? 'bi bi-star-half' : 'bi bi-star'
        }></i>
      </span>
      <span>
        <i style={{color}} className={
            value >= 4 ? 'bi bi-star-fill'//solid star
            :value >=3.5 ? 'bi bi-star-half' : 'bi bi-star'
        }></i>
      </span>
      <span>
        <i style={{color}} className={
            value >= 5 ? 'bi bi-star-fill'//solid star
            :value >=4.5 ? 'bi bi-star-half' : 'bi bi-star'
        }></i>
      </span>
      <span>{text && text}</span>
    </div>
  )
}

export default Rating
